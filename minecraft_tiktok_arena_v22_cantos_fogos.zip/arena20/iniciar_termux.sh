#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
cd "$(dirname "$0")"
echo "=== Minecraft TikTok Arena - Termux ==="
if ! command -v pkg >/dev/null 2>&1; then echo "ERRO: execute este script dentro do Termux no Android."; exit 1; fi
if ! command -v python >/dev/null 2>&1; then pkg install -y python; fi
echo "Instalando dependências Python..."
python -m pip install flask TikTokLive
echo
 echo "Arena: http://127.0.0.1:5000"
echo "Mantenha o Termux aberto. Para encerrar: Ctrl+C"
exec python bridge.py
