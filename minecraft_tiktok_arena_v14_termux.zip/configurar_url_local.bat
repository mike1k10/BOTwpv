@echo off
chcp 65001 >nul
title Configurar URL local - Minecraft TikTok Arena
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Solicitando permissao de administrador...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

set "HOSTS=%SystemRoot%\System32\drivers\etc\hosts"
echo.
echo Configurando http://minecraft.local para abrir o jogo local...
echo.

findstr /i /c:"minecraft.local" "%HOSTS%" >nul
if %errorlevel% neq 0 (
  >>"%HOSTS%" echo 127.0.0.2 minecraft.local
)

net start iphlpsvc >nul 2>&1
netsh interface portproxy delete v4tov4 listenaddress=127.0.0.2 listenport=80 >nul 2>&1
netsh interface portproxy add v4tov4 listenaddress=127.0.0.2 listenport=80 connectaddress=127.0.0.1 connectport=5000
if errorlevel 1 (
  echo ERRO: nao foi possivel configurar a porta 80.
  echo Outra aplicacao pode estar usando essa porta ou o IP de loopback.
  echo Veja o LEIA-ME.txt para instrucoes.
  pause
  exit /b 1
)

ipconfig /flushdns >nul
echo.
echo Configuracao concluida.
echo URL para usar na fonte de navegador do TikTok LIVE Studio:
echo http://minecraft.local
echo.
echo IMPORTANTE:
echo 1. Inicie o jogo com iniciar_windows.bat.
echo 2. Mantenha o servidor aberto durante a LIVE.
echo 3. Esta URL so funciona neste PC, nao e um site publico.
echo.
pause
