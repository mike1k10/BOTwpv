#!/usr/bin/env python3
"""Proxy HTTP restrito a 127.0.0.2:80 -> 127.0.0.1:5000."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

UPSTREAM = "http://127.0.0.1:5000"

class Proxy(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_GET(self): self.forward()
    def do_POST(self): self.forward()
    def do_HEAD(self): self.forward()
    def do_OPTIONS(self): self.forward()

    def forward(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        body = self.rfile.read(length) if length else None
        headers = {}
        for key in ("Content-Type", "Accept", "User-Agent", "Cache-Control"):
            if self.headers.get(key):
                headers[key] = self.headers[key]
        req = Request(UPSTREAM + self.path, data=body, headers=headers, method=self.command)
        try:
            with urlopen(req, timeout=20) as response:
                data = response.read()
                self.send_response(response.status)
                for key in ("Content-Type", "Cache-Control", "Last-Modified", "ETag"):
                    value = response.headers.get(key)
                    if value:
                        self.send_header(key, value)
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Connection", "close")
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(data)
        except HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self.send_header("Content-Type", e.headers.get("Content-Type", "text/plain; charset=utf-8"))
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(data)
        except (URLError, TimeoutError, OSError) as e:
            data = ("Servidor do jogo indisponível. Inicie iniciar_ubuntu.sh.\\n" + str(e)).encode()
            self.send_response(502)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)

    def log_message(self, fmt, *args):
        print("[proxy] " + fmt % args, flush=True)

if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.2", 80), Proxy).serve_forever()
