import asyncio, threading, time, json, os
from collections import deque
from flask import Flask, request, jsonify, send_from_directory
from TikTokLive import TikTokLiveClient
from TikTokLive.events import ConnectEvent, DisconnectEvent, LikeEvent, GiftEvent, CommentEvent, JoinEvent

ROOT = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=ROOT)
events = deque(maxlen=2500)
lock = threading.Lock()
state = {"connected": False, "connecting": False, "username": "", "error": ""}
seq = 0
client = None
loop = None

def push(payload):
    global seq
    with lock:
        seq += 1
        payload["event_id"] = seq
        payload["ts"] = time.time()
        events.append(payload)

def val(obj, *names, default=None):
    for name in names:
        try:
            value = getattr(obj, name)
            if value is not None:
                return value
        except Exception:
            pass
    return default

def user_data(event):
    user = val(event, "user")
    if user is None:
        return {"id": "unknown", "unique_id": "unknown", "name": "Jogador", "avatar": None}
    uid = val(user, "unique_id", default=None) or val(user, "id", default="viewer")
    nickname = val(user, "nickname", default=uid)
    avatar = None
    for attr in ("avatar", "avatar_thumb", "avatar_medium", "avatar_large"):
        a = val(user, attr)
        if a:
            urls = val(a, "url_list", "urls", default=[])
            if urls:
                avatar = urls[0]
                break
            uri = val(a, "uri", "url")
            if uri and str(uri).startswith("http"):
                avatar = str(uri)
                break
    return {"id": str(uid), "unique_id": str(uid), "name": str(nickname), "avatar": avatar}

def run_client(username):
    global client, loop
    async def runner():
        global client, loop
        loop = asyncio.get_running_loop()
        client = TikTokLiveClient(unique_id=username)
        @client.on(ConnectEvent)
        async def on_connect(event):
            state.update(connected=True, connecting=False, username=username, error="")
            push({"type":"status","connected":True,"username":username})
            print(f"[OK] Conectado a @{username}")
        @client.on(DisconnectEvent)
        async def on_disconnect(event):
            state.update(connected=False, connecting=False)
            push({"type":"status","connected":False,"connecting":False,"username":username})
            print("[INFO] LIVE desconectada.")
        @client.on(LikeEvent)
        async def on_like(event):
            data = user_data(event)
            count = val(event, "count", "like_count", default=1)
            try: count = int(count or 1)
            except: count = 1
            push({"type":"like", **data, "count":max(1,count)})
        @client.on(GiftEvent)
        async def on_gift(event):
            data = user_data(event)
            gift = val(event, "gift")
            gift_name = val(gift, "name", "gift_name", default="presente") if gift else "presente"
            repeat = val(event, "repeat_count", "count", default=1)
            try: repeat = max(1,int(repeat or 1))
            except: repeat = 1
            # Ignore intermediate streak updates; act once when streak completes.
            streaking = val(event, "streaking", default=False)
            gift_type = val(gift, "type", "gift_type", default=0) if gift else 0
            if gift_type == 1 and streaking:
                return
            info = val(gift, "info") if gift else None
            diamonds = val(gift, "diamond_count", default=None)
            if diamonds is None and info:
                diamonds = val(info, "diamond_count", default=0)
            try: diamonds = int(diamonds or 0)
            except: diamonds = 0
            push({"type":"gift", **data, "gift_name":str(gift_name), "count":repeat, "coins":diamonds})
        @client.on(CommentEvent)
        async def on_comment(event):
            data = user_data(event)
            push({"type":"comment", **data, "comment":str(val(event,"comment",default=""))})

        @client.on(JoinEvent)
        async def on_join(event):
            data = user_data(event)
            push({"type":"join", **data})
            print(f"[JOIN] {data.get('name')} (@{data.get('unique_id')}) entrou na LIVE")
        try:
            print(f"[INFO] Tentando conectar a @{username}...")
            # TikTokLive.start() returns a background Task. Keep the asyncio loop alive
            # for that task; otherwise asyncio.run() closes the loop immediately.
            task = await client.start()
            state.update(connecting=True, error="")
            await task
        except Exception as e:
            state.update(connected=False, connecting=False, error=str(e))
            push({"type":"status","connected":False,"connecting":False,"username":username,"error":str(e)})
            print("[ERRO] Falha na conexão:", repr(e))
        finally:
            if not state.get("connected"):
                state["connecting"] = False
    asyncio.run(runner())

@app.get("/")
def index():
    return send_from_directory(ROOT, "index.html")

@app.post("/api/connect")
def connect():
    global client
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip().lstrip("@")
    if not username:
        return jsonify(ok=False, error="Informe o @ da conta TikTok."), 400
    if state["connected"]:
        try:
            if client and loop:
                asyncio.run_coroutine_threadsafe(client.stop(), loop)
        except Exception:
            pass
    state.update(connected=False, connecting=True, username=username, error="")
    push({"type":"status","connected":False,"connecting":True,"username":username,"error":""})
    threading.Thread(target=run_client, args=(username,), daemon=True).start()
    return jsonify(ok=True, username=username, message="Tentando conectar; consulte /api/health para o estado.")

@app.get("/api/status")
def status():
    return jsonify(state)

@app.get("/api/health")
def health():
    try:
        import TikTokLive
        version = getattr(TikTokLive, "__version__", "instalado")
    except Exception as e:
        version = "erro: " + str(e)
    return jsonify(server="ok", tiktoklive=version, connected=state["connected"], connecting=state.get("connecting", False), username=state["username"], error=state["error"], queued_events=len(events))

@app.get("/api/events")
def get_events():
    try: after = int(request.args.get("after", "0"))
    except: after = 0
    with lock:
        result = [e.copy() for e in events if e["event_id"] > after]
    return jsonify(events=result)

if __name__ == "__main__":
    print("Minecraft TikTok Arena abrindo em http://127.0.0.1:5000")
    print("Para usar no OBS: adicione uma fonte Navegador com essa URL.")
    app.run(host="127.0.0.1", port=5000, threaded=True, debug=False)
