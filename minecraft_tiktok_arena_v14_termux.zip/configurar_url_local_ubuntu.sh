#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
HOSTS=/etc/hosts
HOST_ENTRY="127.0.0.2 minecraft.local"
PID_FILE=/tmp/minecraft_tiktok_arena_proxy.pid

if [[ $EUID -eq 0 ]]; then
  SUDO=()
else
  SUDO=(sudo)
fi

echo "Este script só adiciona uma entrada local em /etc/hosts e inicia um proxy restrito ao próprio PC."
echo "Não instala pacotes, não abre portas na rede e não altera a configuração global do firewall."
echo

if ! grep -Eq '^[[:space:]]*127\\.0\\.0\\.2[[:space:]]+minecraft\\.local([[:space:]]|$)' "$HOSTS"; then
  echo "Adicionando minecraft.local em /etc/hosts..."
  printf '%s\\n' "$HOST_ENTRY" | "${SUDO[@]}" tee -a "$HOSTS" >/dev/null
else
  echo "Entrada minecraft.local já existe."
fi

if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  echo "Proxy já está em execução (PID $(cat "$PID_FILE"))."
else
  echo "Iniciando proxy local na porta 80 (pode pedir a senha do sudo)..."
  # O proxy escuta apenas em 127.0.0.2, não em interfaces da rede.
  "${SUDO[@]}" -v
  "${SUDO[@]}" bash -c "cd '$PWD'; nohup python3 '$PWD/local_proxy_ubuntu.py' >/tmp/minecraft_tiktok_arena_proxy.log 2>&1 & echo \\$! > '$PID_FILE'"
  sleep 1
  if ! "${SUDO[@]}" kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    echo "Não consegui iniciar o proxy. Veja /tmp/minecraft_tiktok_arena_proxy.log"
    echo "Talvez a porta 80 esteja ocupada."
    exit 1
  fi
fi

echo
echo "Configurado. Agora:"
echo "  1. Execute ./iniciar_ubuntu.sh em outra janela."
echo "  2. No TikTok LIVE Studio, use: http://minecraft.local"
echo
echo "Teste no navegador após iniciar o servidor: http://minecraft.local/api/health"
echo "Para desfazer: ./remover_url_local_ubuntu.sh"
