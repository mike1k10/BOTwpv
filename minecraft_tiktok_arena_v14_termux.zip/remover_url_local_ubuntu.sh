#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
PID_FILE=/tmp/minecraft_tiktok_arena_proxy.pid
if [[ $EUID -eq 0 ]]; then SUDO=(); else SUDO=(sudo); fi

if [[ -f "$PID_FILE" ]]; then
  PID="$(cat "$PID_FILE")"
  if [[ "$PID" =~ ^[0-9]+$ ]]; then
    "${SUDO[@]}" kill "$PID" 2>/dev/null || true
  fi
  rm -f "$PID_FILE"
fi

# Remove somente a linha exata que este instalador adiciona.
"${SUDO[@]}" python3 - <<'PY'
from pathlib import Path
p = Path("/etc/hosts")
lines = p.read_text().splitlines()
target = "127.0.0.2 minecraft.local"
filtered = [line for line in lines if line.strip() != target]
if len(filtered) != len(lines):
    p.write_text("\\n".join(filtered) + "\\n")
PY

echo "Configuração minecraft.local removida."
echo "Nenhum pacote ou configuração de firewall foi alterado."
