#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"

echo "============================================"
echo " MINECRAFT TIKTOK ARENA - UBUNTU"
echo "============================================"
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERRO: Python 3 não está instalado."
  echo "Instale com: sudo apt update && sudo apt install python3 python3-venv python3-pip"
  exit 1
fi

if [ ! -d .venv ]; then
  python3 -m venv .venv || {
    echo "Não foi possível criar o ambiente virtual."
    echo "No Ubuntu, instale: sudo apt install python3-venv"
    exit 1
  }
fi

echo "Atualizando dependências dentro do ambiente isolado (.venv)..."
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install --upgrade TikTokLive Flask

echo
echo "Servidor local: http://127.0.0.1:5000"
echo "Para usar o endereço personalizado, execute antes:"
echo "  ./configurar_url_local_ubuntu.sh"
echo
echo "Mantenha esta janela aberta durante a LIVE."
exec .venv/bin/python bridge.py
