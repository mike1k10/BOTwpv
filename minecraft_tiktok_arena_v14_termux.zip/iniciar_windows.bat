@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Minecraft TikTok Arena - Conexao
echo ============================================
echo   MINECRAFT TIKTOK ARENA - CONECTOR
echo ============================================
echo.
echo Atualizando TikTokLive e dependencias...
py -m pip install --upgrade TikTokLive Flask
if errorlevel 1 python -m pip install --upgrade TikTokLive Flask
echo.
echo Iniciando servidor em http://127.0.0.1:5000
echo MANTENHA ESTA JANELA ABERTA DURANTE A LIVE.
echo.
py bridge.py
if errorlevel 1 python bridge.py
echo.
echo O servidor terminou. Leia a mensagem de erro acima.
pause
