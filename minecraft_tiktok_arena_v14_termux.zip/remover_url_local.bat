@echo off
chcp 65001 >nul
title Remover URL local - Minecraft TikTok Arena
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
set "HOSTS=%SystemRoot%\System32\drivers\etc\hosts"
netsh interface portproxy delete v4tov4 listenaddress=127.0.0.2 listenport=80 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=$env:SystemRoot+'\System32\drivers\etc\hosts'; Get-Content $p | Where-Object { $_ -notmatch 'minecraft\.local' } | Set-Content -Encoding ascii $p"
ipconfig /flushdns >nul
echo Configuracao local removida.
pause
